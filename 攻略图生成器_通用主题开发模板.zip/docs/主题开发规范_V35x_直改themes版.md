# 主题开发规范（V35.x・直改 themes 版）

> 本文是主题开发专项细则。项目级总约束请先阅读根目录 `攻略图生成器_通用开发与AI协作要求.md`。
> 若本文与最新实际工程、用户最新明确需求或项目级总约束冲突，应先核对真实代码与调用链，不得机械套用旧规则。


# 1. 当前维护方式

本项目采用：

```text
themes/       主题 JSON
renderers/    独立版式 Python
assets/       素材
```

**不使用 `theme_packages/`。**

所以：

- 修改 `themes/*.json`：直接覆盖 JSON；
- 修改 `renderers/*.py`：直接覆盖 Python，并彻底重启生成器；
- 新增素材：放 `assets/<theme_id>/`；
- 不生成 `.guide-theme`。

---

# 2. 信息优先级

所有新主题统一遵守：

```text
第一：D1～D7 每日操作
第二：每天的剩余 / 期望 / 关键状态
第三：资源预算、奖励、风险
第四：标题与活动身份
第五：加群信息
第六：角色、背景纹理、路线、机器装饰、印章等
```

这不是视觉建议，而是布局优先级。

如果正文与装饰冲突，删除或移动装饰。

---

# 3. D1～D7 必须拿到最大版面

通常建议：

- D1～D7 占可用内容高度的 **55%～70%**；
- 顶部标题 + 资源 + 奖励控制在 **18%～28%**；
- 风险 + Footer 通常控制在 **8%～15%**。

这不是死数字，但如果一个主题反过来让顶部装饰占一半、D1～D7 挤在很小区域，通常就是错误方向。

每日操作建议：

- 尽量一条编号操作占一行；
- 先增加卡片宽度/高度；
- 再合理换行；
- 最后才缩字号；
- 不要无限缩小；
- 同级 Day 不要因为文本长短出现完全不同的字号。

---

# 4. 所有信息都必须可读

以下都不能为了“省版面”缩成看不清的小字：

- 奖励名称与数量；
- 资源名称与数值；
- 剩余 / 期望；
- 风险提示；
- 加群信息；
- 特殊日标签。

推荐开发时做一个真实手机测试：

> 把 1080 宽成图按手机宽度完整显示，不主动放大。
> 如果正常视力仍需要捏合放大才能读常规正文，这版不通过。

---

# 5. 重复组件必须统一规格

典型组件：

- 每天的“剩余 / 期望”；
- 资源行；
- 奖励行；
- 编号圆点；
- Day 标签。

同一类组件应尽量使用统一：

```text
字号
图标框大小
图标实际大小
行高
内边距
左右间距
对齐基线
```

不要出现 D1 文字 18、D2 14、D3 11，只因为 D2/D3 更长。

正确策略：

```text
统一字号
→ 统一宽度
→ 必要时省略次要标签 / 合理换行
→ 不让同类组件各自缩放
```

---

# 6. Theme / Variant / Renderer 判断

## Variant

只改变：

- 配色；
- 纸张；
- 印刷质感；
- 标题语言；
- 少量装饰；
- 角色着色。

核心信息位置不改变。

## 新 Theme、复用 Renderer

主题需要独立显示，但版式完全同族。

## 新 Theme + 独立 Renderer

出现以下情况通常应该新 Renderer：

- Day 变成地图节点；
- Day 变成漫画分镜；
- 整张图变成机器面板；
- 模块顺序明显变化；
- 需要动态安全区；
- 需要复杂素材摆放；
- 需要明显不同的空间阅读方式。

---

# 7. manifest.json

推荐：

```json
{
  "schema_version": 1,
  "id": "your_theme",
  "name": "你的主题",
  "version": "1.0.0",
  "author": "你的名字",
  "description": "一句话说明主题",
  "engine_min_version": "35.7",
  "entry_config": "theme.json",
  "variants": [
    {
      "id": "default",
      "name": "默认",
      "config": "variants/default.json"
    }
  ]
}
```

ID 建议只使用：

```text
A-Z a-z 0-9 _ - .
```

---

# 8. theme.json

基础颜色至少保留：

```json
{
  "renderer": {
    "style": "your_theme",
    "layout_version": "v1",

    "day_action_font_size": 25,
    "day_action_min_font_size": 16,

    "risk_font_size": 18,
    "risk_min_font_size": 15,

    "footer_font_size": 18,
    "footer_min_font_size": 14
  },
  "colors": {
    "primary": "#A33B2F",
    "dark": "#202020",
    "light": "#FFFDF8",
    "chip": "#E8E1D3"
  }
}
```

当前主题系统最终配置至少需要：

```text
colors.primary
colors.dark
colors.light
colors.chip
```

---

# 9. Variant 只写差异

不要复制完整 `theme.json`。

基础：

```json
{
  "renderer": {
    "style": "your_theme",
    "day_action_font_size": 25
  }
}
```

变体：

```json
{
  "renderer": {
    "page_style": "aged_print"
  }
}
```

最终递归合并。

---

# 10. Renderer 最小接口

```python
STYLE_IDS = ("your_theme",)

def render(guide, out_path, services):
    ...
```

必须：

- `renderer.style` 与 STYLE_IDS 一致；
- STYLE_ID 不与其他 Renderer 冲突；
- 不直接 import `guide_image_generator`；
- 使用 `services` / `SharedRendererTools`。

---

# 11. classic_cards 不要随便删除

当前经典 Renderer 应保留：

```python
STYLE_IDS = ("classic_clean", "classic_cards")
```

其中：

- `classic_clean` 是主题；
- `classic_cards` 是主引擎的经典兜底 ID。

删除 `classic_cards` 会破坏未知 Renderer 的回退。

---

# 12. Renderer 修改后必须重启

Python Renderer 会被模块系统缓存。

所以修改：

```text
renderers/*.py
```

后：

**彻底退出并重新启动生成器。**

重新加载 JSON 不能替代重启。

---

# 13. 素材

推荐：

```text
assets/<theme_id>/
├─ characters/
├─ textures/
├─ icons/
└─ decorations/
```

使用相对路径。

角色与装饰原则：

```text
正文 > 素材
```

没有足够空间时可以：

- 缩小；
- 移到真实空白；
- 隐藏；
- 省略。

不要压缩 D1～D7 正文去给角色腾地方。

---

# 14. 稳定随机

如果随机角色、印章、弹珠、真凶等：

```python
seed = f"{guide.get('sheet')}|{guide.get('title')}|{variant_key}"
rng = random.Random(seed)
```

同活动、同变体稳定；不同变体可不同。

如果随机对象必须“实际出现在图中”，应该：

```text
先布局
→ 得到实际可见集合
→ 再随机
```

---

# 15. 推荐布局顺序

```text
1. 画布
2. 标题
3. 资源 / 奖励
4. D1～D7（先保证最大区域）
5. 剩余 / 期望
6. 风险
7. Footer
8. 最后加角色、轨道、纹理、机械件、印章
```

如果第 8 步破坏了 1～7，删除第 8 步。

---

# 16. 长文本处理顺序

正确：

```text
增加正文宽度
→ 增加正文高度
→ 减少装饰
→ 减少无效留白
→ 合理换行
→ 轻微缩字号
```

错误：

```text
文字一长 → 直接缩到 10px
```

对于 D1～D7，建议配置独立：

```text
day_action_font_size
day_action_min_font_size
```

不要与 Footer 共用一个字体参数。

---

# 17. 风险与 Footer

风险和加群可以比 D1～D7 占更小版面，但不代表可以小到看不清。

原则：

- 缩的是**区域高度和留白**；
- 不是把字无限缩小。

Footer 有群头像时：

- 图标和文字作为一组对齐；
- 图标不能把文字挤到极小字号；
- 头像缺失要安全回退。

---

# 18. 当前主题设计参照

目前保留的主题可以作为六种参照：

- `classic_clean`：最高可读性基准；
- `handwritten_notes`：纸张/笔迹；
- `classified_dossier`：强世界观 + 模块清晰；
- `battle_route`：空间路线；
- `comic_storyboard`：复杂媒介、角色、安全区；
- `arcade_pinball`：实体机器面板，但 D1～D7 仍为阅读主体。

新主题应该先问：

> 它与这六类相比，新增了什么真正不同的阅读/媒介语言？

如果答案只是换颜色，不值得新 Renderer。

---

# 19. 发布

本项目当前发布方式：

```text
renderers/    有 Renderer 改动才放
themes/       主题配置
assets/       有素材才放
README
```

**不包含 `theme_packages/`。**

如果同时改主引擎，再额外放：

```text
guide_image_generator.py
```

发布前：

- JSON 校验；
- Renderer 编译；
- 长文本压力测试；
- 手机可读性测试；
- D1～D7 优先级检查；
- 重复组件统一规格检查。
