覆盖说明（直改 themes 模板）

把 ZIP 内对应目录直接覆盖到生成器根目录：

- themes/
- renderers/（如果有）
- assets/（如果有）

不使用 theme_packages，不需要 .guide-theme。

只修改 JSON 时通常不需要重启；
修改 renderers/*.py 后必须彻底关闭并重新启动生成器。

布局开发第一优先级：
D1~D7 每日操作要占最大有效版面，并保证手机上不放大也能读。
