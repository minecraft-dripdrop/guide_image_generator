把主题素材放在这里。

推荐结构：

assets/your_theme/
├─ characters/
├─ textures/
├─ icons/
└─ decorations/

建议：
1. 使用相对路径；
2. PNG/WebP 角色优先透明背景；
3. 角色是装饰时，不要让角色决定正文布局；
4. 缺少素材时 Renderer 应安全跳过，而不是崩溃；
5. 不要把字体文件随模板/主题包分发。
