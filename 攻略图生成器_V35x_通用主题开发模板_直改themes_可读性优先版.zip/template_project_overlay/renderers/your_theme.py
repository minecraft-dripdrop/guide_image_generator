# -*- coding: utf-8 -*-
"""Readability-first Renderer skeleton.

Hard rule:
D1-D7 daily actions are the primary content.
Decoration must yield to text, never the opposite.
"""
from pathlib import Path
from PIL import Image, ImageDraw
from .shared import SharedRendererTools

STYLE_IDS = ("your_theme",)


def _rcfg(guide):
    data = (guide.get("theme_config") or {}).get("renderer")
    return dict(data) if isinstance(data, dict) else {}


def render(guide, out_path: Path, services):
    tools = SharedRendererTools(services)
    rcfg = _rcfg(guide)
    colors = tools.colors(guide, {
        "background": "#F2EFE8",
        "paper": "#FFFDF8",
        "ink": "#202020",
        "muted": "#6F6B64",
        "accent": "#A33B2F",
        "rule": "#B6AEA0",
        "risk": "#FFF0DF",
    })

    W, H = int(services.W), int(services.H)
    img = Image.new("RGBA", (W, H), colors["background"])
    d = ImageDraw.Draw(img)

    # ------------------------------------------------------------
    # 1) Compact header. Do not let the header steal Day space.
    # ------------------------------------------------------------
    title = services.clean(str(guide.get("title") or "活动攻略"))
    services.draw_left(
        d, (48, 34, W - 48, 120),
        title, colors["ink"],
        max_size=int(rcfg.get("title_font_size", 36) or 36),
        min_size=26, bold=True, max_lines=2, line_gap=2, valign="center",
    )
    d.line((48, 132, W - 48, 132), fill=colors["rule"], width=3)

    # ------------------------------------------------------------
    # 2) Compact resource / reward summary.
    # These are important, but must not dominate the page.
    # ------------------------------------------------------------
    tools.draw_simple_kpis(
        d, guide, (48, 150, W - 48, 260),
        fg=colors["ink"], accent=colors["accent"],
        fill=colors["paper"], border=colors["rule"], compact=True,
    )

    # ------------------------------------------------------------
    # 3) D1-D7: PRIMARY CONTENT AREA.
    # About 65% of the lower page is reserved for daily actions.
    # ------------------------------------------------------------
    days = list(guide.get("days") or [])[:7]
    day_top = 286
    risk_h = 142
    footer_h = 66
    bottom_gap = 22
    day_bottom = H - risk_h - footer_h - bottom_gap - 20

    if days:
        gap = 10
        available = day_bottom - day_top - gap * (len(days) - 1)
        cell_h = max(132, int(available / len(days)))

        for i, info in enumerate(days):
            y1 = day_top + i * (cell_h + gap)
            y2 = min(day_bottom, y1 + cell_h)

            d.rounded_rectangle(
                (48, y1, W - 48, y2),
                radius=16, fill=colors["paper"],
                outline=colors["rule"], width=2,
            )

            day = services.clean(str(info.get("day") or f"D{i+1}"))
            target = services.clean(str(info.get("target") or ""))
            action = services.clean(str(info.get("action") or "按计划执行"))

            # Compact Day header.
            services.draw_left(
                d, (66, y1 + 10, 175, y1 + 44),
                day, colors["accent"],
                max_size=25, min_size=20, bold=True,
                max_lines=1, valign="center",
            )
            if target:
                services.draw_left(
                    d, (184, y1 + 10, W - 68, y1 + 44),
                    "目标：" + target, colors["muted"],
                    max_size=16, min_size=14, bold=True,
                    max_lines=1, valign="center",
                )

            # Largest normal text on the page.
            # First add space; only then allow limited font shrinking.
            services.draw_left(
                d, (68, y1 + 48, W - 68, y2 - 12),
                action, colors["ink"],
                max_size=int(rcfg.get("day_action_font_size", 25) or 25),
                min_size=int(rcfg.get("day_action_min_font_size", 16) or 16),
                bold=True, max_lines=5,
                line_gap=int(rcfg.get("day_action_line_gap", 5) or 5),
                valign="center",
            )

    # ------------------------------------------------------------
    # 4) Risk: compact AREA, but readable FONT.
    # Reduce padding, not legibility.
    # ------------------------------------------------------------
    risk_y1 = H - footer_h - risk_h - 16
    risk_y2 = H - footer_h - 22
    d.rounded_rectangle(
        (48, risk_y1, W - 48, risk_y2),
        radius=14, fill=colors["risk"],
        outline=colors["accent"], width=2,
    )
    risk_items = tools.risk_items(guide)
    risk_text = "  ·  ".join(risk_items) if risk_items else "暂无风险提示"
    services.draw_left(
        d, (66, risk_y1 + 12, W - 66, risk_y2 - 12),
        "提示：" + risk_text, colors["ink"],
        max_size=int(rcfg.get("risk_font_size", 18) or 18),
        min_size=int(rcfg.get("risk_min_font_size", 15) or 15),
        bold=True, max_lines=3, line_gap=4, valign="center",
    )

    # ------------------------------------------------------------
    # 5) Footer: small area, still readable.
    # ------------------------------------------------------------
    tools.footer_plain(
        d, guide,
        fg=colors["muted"], line=colors["rule"], bg=colors["paper"],
        height=footer_h,
    )

    # ------------------------------------------------------------
    # 6) Decoration LAST.
    # Add theme-specific art only in genuine leftover whitespace.
    # If art overlaps text, delete art rather than shrinking text.
    # ------------------------------------------------------------

    tools.save(img, out_path, guide)
