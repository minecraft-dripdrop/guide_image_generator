# 工具使用｜直改 themes 版

## 校验主题

```bash
python tools/validate_theme.py \
  template_project_overlay/themes/your_theme \
  --renderer template_project_overlay/renderers/your_theme.py
```

## 生成覆盖包

```bash
python tools/build_overlay.py \
  --project-root template_project_overlay \
  --theme-id your_theme \
  --renderer your_theme \
  --output dist
```

输出：

```text
dist/your_theme-1.0.0-overlay.zip
```

这个流程：

- 不使用 theme_packages；
- 不生成 .guide-theme；
- 直接覆盖 themes/renderers/assets。

如果没有独立 Renderer，省略：

```text
--renderer your_theme
```
