# -*- coding: utf-8 -*-
"""Standalone validator for a V35.x theme folder."""
from pathlib import Path
import argparse
import ast
import json
import re
import sys

REQUIRED_COLORS = ("primary", "dark", "light", "chip")
SAFE_RE = re.compile(r"^[A-Za-z0-9_.-]+$")
HEX_RE = re.compile(r"^#[0-9A-Fa-f]{6}(?:[0-9A-Fa-f]{2})?$")


def load_json(path):
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise RuntimeError(f"{path}: JSON 读取失败: {exc}")
    if not isinstance(data, dict):
        raise RuntimeError(f"{path}: 顶层必须是对象")
    return data


def deep_merge(base, override):
    out = dict(base) if isinstance(base, dict) else {}
    for k, v in (override or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def resolve_refs(value, root):
    if isinstance(value, str) and value.startswith("$"):
        cur = root
        for part in value[1:].split("."):
            if not isinstance(cur, dict) or part not in cur:
                raise RuntimeError(f"引用不存在: {value}")
            cur = cur[part]
        return cur
    if isinstance(value, dict):
        return {k: resolve_refs(v, root) for k, v in value.items()}
    if isinstance(value, list):
        return [resolve_refs(v, root) for v in value]
    return value


def renderer_style_ids(renderer_path):
    tree = ast.parse(renderer_path.read_text(encoding="utf-8"))
    for node in tree.body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id == "STYLE_IDS":
                    try:
                        value = ast.literal_eval(node.value)
                    except Exception:
                        return ()
                    if isinstance(value, str):
                        return (value,)
                    if isinstance(value, (list, tuple)):
                        return tuple(str(x) for x in value)
    return ()


def validate(theme_dir, renderer_path=None):
    theme_dir = Path(theme_dir).resolve()
    errors = []
    notes = []

    mp = theme_dir / "manifest.json"
    if not mp.exists():
        errors.append("缺少 manifest.json")
        return errors, notes

    try:
        manifest = load_json(mp)
    except Exception as exc:
        return [str(exc)], notes

    theme_id = str(manifest.get("id") or "")
    if not theme_id or not SAFE_RE.match(theme_id):
        errors.append("manifest.id 为空或含不安全字符")

    if int(manifest.get("schema_version", 1) or 1) != 1:
        errors.append("schema_version 当前应为 1")

    version = str(manifest.get("version") or "").strip()
    if not version:
        errors.append("缺少 manifest.version")

    entry = str(manifest.get("entry_config") or "theme.json")
    base_path = theme_dir / entry
    if not base_path.exists():
        errors.append(f"缺少 entry_config: {entry}")
        return errors, notes

    try:
        base = load_json(base_path)
    except Exception as exc:
        errors.append(str(exc))
        return errors, notes

    variants = manifest.get("variants")
    if not isinstance(variants, list) or not variants:
        errors.append("manifest.variants 至少需要一个条目")
        return errors, notes

    seen = set()
    styles = set()

    for raw in variants:
        if not isinstance(raw, dict):
            errors.append("variants 中存在非对象条目")
            continue
        vid = str(raw.get("id") or "")
        if not vid or not SAFE_RE.match(vid):
            errors.append(f"非法 variant.id: {vid!r}")
            continue
        if vid in seen:
            errors.append(f"重复 variant.id: {vid}")
        seen.add(vid)

        rel = str(raw.get("config") or f"variants/{vid}.json")
        vp = theme_dir / rel
        if not vp.exists():
            errors.append(f"{vid}: 缺少 {rel}")
            continue

        try:
            override = load_json(vp)
            merged = resolve_refs(deep_merge(base, override), deep_merge(base, override))
        except Exception as exc:
            errors.append(f"{vid}: {exc}")
            continue

        colors = merged.get("colors")
        if not isinstance(colors, dict):
            errors.append(f"{vid}: 缺少 colors")
        else:
            for key in REQUIRED_COLORS:
                value = colors.get(key)
                if not isinstance(value, str) or not value.startswith("#"):
                    errors.append(f"{vid}: colors.{key} 缺失或非法")
            for key, value in colors.items():
                if isinstance(value, str) and value.startswith("#") and not HEX_RE.match(value):
                    notes.append(f"{vid}: colors.{key}={value} 不是标准 6/8 位 HEX")

        renderer = merged.get("renderer")
        if isinstance(renderer, dict):
            # Readability advisory: D1-D7 should never be sacrificed to decoration.
            day_size = renderer.get("day_action_font_size")
            day_min = renderer.get("day_action_min_font_size")
            risk_size = renderer.get("risk_font_size")
            footer_size = renderer.get("footer_font_size")
            try:
                if day_size is not None and float(day_size) < 22:
                    notes.append(f"{vid}: day_action_font_size={day_size} 偏小；建议从 22~28 起调并以手机实测为准")
                if day_min is not None and float(day_min) < 15:
                    notes.append(f"{vid}: day_action_min_font_size={day_min} 过低风险；D1-D7 不应缩成蚂蚁字")
                if risk_size is not None and float(risk_size) < 14:
                    notes.append(f"{vid}: risk_font_size={risk_size} 可能影响风险提示可读性")
                if footer_size is not None and float(footer_size) < 13:
                    notes.append(f"{vid}: footer_font_size={footer_size} 可能影响加群信息可读性")
            except Exception:
                pass

            style = str(renderer.get("style") or "").strip()
            if style:
                styles.add(style)
            else:
                notes.append(f"{vid}: renderer.style 为空")

    if renderer_path:
        renderer_path = Path(renderer_path).resolve()
        if not renderer_path.exists():
            errors.append(f"Renderer 不存在: {renderer_path}")
        else:
            try:
                compile(renderer_path.read_text(encoding="utf-8"), str(renderer_path), "exec")
            except Exception as exc:
                errors.append(f"Renderer 编译失败: {exc}")
            ids = renderer_style_ids(renderer_path)
            if not ids:
                errors.append("Renderer 没有可识别的 STYLE_IDS")
            for style in styles:
                if style not in ids:
                    errors.append(
                        f"theme renderer.style={style!r} 不在 Renderer STYLE_IDS={ids!r}"
                    )

    return errors, notes


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("theme_dir")
    ap.add_argument("--renderer")
    args = ap.parse_args()

    errors, notes = validate(args.theme_dir, args.renderer)

    for n in notes:
        print("[提示]", n)
    if errors:
        for e in errors:
            print("[错误]", e)
        return 1
    print("[通过] 主题结构、变体合并、必需颜色和 Renderer 基础检查均通过")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
