# -*- coding: utf-8 -*-
"""Build a direct-copy overlay ZIP. No theme_packages and no .guide-theme."""
from pathlib import Path
import argparse
import json
import zipfile

SKIP = {"__pycache__", ".git", ".idea", ".vscode", "theme_packages"}


def skip(p):
    return any(part in SKIP for part in p.parts) or p.suffix in {".pyc", ".pyo", ".guide-theme"}


def add_tree(zf, src, arc):
    if not src.exists():
        return
    for p in src.rglob("*"):
        if p.is_file() and not skip(p):
            zf.write(p, arcname=str(Path(arc) / p.relative_to(src)).replace("\\", "/"))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--project-root", required=True)
    ap.add_argument("--theme-id", required=True)
    ap.add_argument("--renderer", default="")
    ap.add_argument("--output", default="dist")
    args = ap.parse_args()

    root = Path(args.project_root).resolve()
    theme = root / "themes" / args.theme_id
    if not theme.exists():
        raise SystemExit(f"找不到主题目录: {theme}")

    manifest = json.loads((theme / "manifest.json").read_text(encoding="utf-8"))
    version = str(manifest.get("version") or "0.0.0")

    out_dir = Path(args.output)
    if not out_dir.is_absolute():
        out_dir = root / out_dir
    out_dir.mkdir(parents=True, exist_ok=True)

    out = out_dir / f"{args.theme_id}-{version}-overlay.zip"

    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        add_tree(z, theme, f"themes/{args.theme_id}")

        if args.renderer:
            rp = root / "renderers" / f"{args.renderer}.py"
            if not rp.exists():
                raise SystemExit(f"找不到 Renderer: {rp}")
            z.write(rp, arcname=f"renderers/{args.renderer}.py")

        add_tree(z, root / "assets" / args.theme_id, f"assets/{args.theme_id}")

        readme = root / "README_覆盖说明.txt"
        if readme.exists():
            z.write(readme, arcname="README_覆盖说明.txt")

    print("overlay:", out)
    if args.renderer:
        print("提示：Renderer 改动后必须彻底重启生成器。")
    print("本工具不会生成 theme_packages，也不会生成 .guide-theme。")


if __name__ == "__main__":
    main()
